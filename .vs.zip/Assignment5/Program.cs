﻿using var game = new Assignment5.Assignment5();
game.Run();
